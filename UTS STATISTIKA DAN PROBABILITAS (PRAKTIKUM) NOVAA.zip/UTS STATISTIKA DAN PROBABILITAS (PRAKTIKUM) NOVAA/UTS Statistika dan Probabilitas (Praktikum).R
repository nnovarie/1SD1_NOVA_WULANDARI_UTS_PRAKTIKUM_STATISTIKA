# DATA PENJUALAN TOKO A TAHUN 2010-2020

tahun <- 2010:2020

gula <- c(50, 70, 100, 120, 110, 100,
          120, 135, 140, 150, 145)

minyak <- c(80, 85, 90, 100, 120, 125,
            135, 140, 150, 190, 195)

sabun <- c(55, 70, 80, 95, 80, 100,
           105, 110, 120, 100, 130)

datatoko <- data.frame(
  Tahun = tahun,
  Gula = gula,
  Minyak = minyak,
  Sabun = sabun
)

write.csv(datatoko, "datatoko.csv", row.names = FALSE)

datatoko <- read.csv("datatoko.csv")

print(datatoko)

summary(datatoko[, c("Gula", "Minyak", "Sabun")])

par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))


plot(datatoko$Tahun, datatoko$Gula,
     type = "o",
     col = "red",
     pch = 16,
     main = "Penjualan Gula (2010-2020)",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")


plot(datatoko$Tahun, datatoko$Minyak,
     type = "o",
     col = "blue",
     pch = 16,
     main = "Penjualan Minyak (2010-2020)",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")


plot(datatoko$Tahun, datatoko$Sabun,
     type = "o",
     col = "brown",
     pch = 16,
     main = "Penjualan Sabun (2010-2020)",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")


plot(datatoko$Tahun, datatoko$Gula,
     type = "o",
     col = "red",
     pch = 16,
     ylim = c(0, 200),
     main = "Data Penjualan Produk di Toko A",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")

lines(datatoko$Tahun, datatoko$Minyak,
      type = "o",
      col = "blue",
      pch = 16)

lines(datatoko$Tahun, datatoko$Sabun,
      type = "o",
      col = "brown",
      pch = 16)


legend("topleft",
       legend = c("Gula", "Minyak", "Sabun"),
       col = c("red", "blue", "brown"),
       lty = 1,
       pch = 16,
       cex = 0.7)

par(mfrow = c(1, 1))